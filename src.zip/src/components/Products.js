import React from 'react';
import Product from './Product';
import './styles/Products.css';


export default function Products(props) {

  return (
    <div className='products'>
      {props.products.map((item) =>
        <div >
          <Product itemData={item} onAddProductToCartClick={props.onAddProductToCartClick} />
        </div>
      )}
    </div>
  )
}