import React from 'react';
import './styles/Product.css';
// import { makeStyles } from '@material-ui/core/styles';
import IconButton from '@material-ui/core/IconButton';
import AddShoppingCartIcon from '@material-ui/icons/AddShoppingCart';

// const useStyles = makeStyles(theme => ({
//   root: {
//     '& > *': {
//       margin: theme.spacing(1),
//     },
//   },
// }));

export default function Product(props) {

  // const classes = useStyles();

  const handleAddProductToCartClick = () => {
    props.onAddProductToCartClick({ ...props.itemData, counter: 1, itemTotalPrice: props.itemData.prices[1].amount });
  }

  return (
    <div className='product'>
      <img src='productMock.jpg' alt="" height="150" width="250" />
      <label>{props.itemData.title}</label>
      <label>{props.itemData.prices[1].amount} {props.itemData.prices[1].currency}</label>
      <IconButton aria-label="AddShoppingCartIcon" onClick={handleAddProductToCartClick}>
        <AddShoppingCartIcon />
      </IconButton>
    </div>
  )
}