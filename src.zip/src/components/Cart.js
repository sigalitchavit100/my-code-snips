import React from 'react';
import Item from './Item';
import './styles/Cart.css';

export default function Cart(props) {

    return (
        <div className='cart'>
            {props.items.map((item) =>
                <Item itemData={item} onRemoveProductFromCart={props.onRemoveProductFromCart}
                onPriceChange={props.onPriceChange} />
            )}
            {/* { console.log('Cart rendered') } */}
        </div>
    );
}