import React, { useState } from 'react';
import Products from './Products';
import Cart from './Cart';
import './styles/App.css';
import productsMock from '../data/productsMock';


function App() {

  const [itemsArray, setItemsArray] = useState([]);
  const [productsArray, setProductsArray] = useState(productsMock);
  const [total, setTotal] = useState(0);

  const handleAddProductToCart = (item) => {
    const index = itemsArray.findIndex(it => it.id === item.id);
    if (index === -1) {
      setItemsArray([...itemsArray, item]);
      setTotal(total + item.itemTotalPrice);
    }
  }

  const handleRemoveProductFromCart = (item) => {
    const newCart = itemsArray.filter(product => product.id !== item.id);
    setItemsArray(newCart);
    if (itemsArray.length === 0) {
      setTotal(0);
    }
    else setTotal(total - item.itemTotalPrice);
  }

  const handlePriceByType = (itemData, count, type) => {
    if (type === "ADD") {
      itemData.itemTotalPrice += itemData.prices[1].amount;
      setTotal(total + itemData.prices[1].amount);
    }
    else { // "SUB"
      itemData.itemTotalPrice -= itemData.prices[1].amount;
      setTotal(total - itemData.prices[1].amount);
    }
   
    itemData.counter = count;
  }

  return (
    <div className='flex-container'>
      <h1 className='header'>My Shop</h1>
      <Cart items={itemsArray} onRemoveProductFromCart={handleRemoveProductFromCart}
        onPriceChange={handlePriceByType} />
      <h4 className='header'>Total cart: {total}</h4>
      <Products products={productsArray} onAddProductToCartClick={handleAddProductToCart} />
    </div>
  );
}

export default App;