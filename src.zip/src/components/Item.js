import React, { useState } from 'react';
import './styles/Item.css';
// import { makeStyles } from '@material-ui/core/styles';
import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@material-ui/icons/Delete';
import AddIcon from '@material-ui/icons/Add';
import RemoveIcon from '@material-ui/icons/Remove';

// const useStyles = makeStyles(theme => ({
//     root: {
//         '& > *': {
//             margin: theme.spacing(1),
//         },
//     },
// }));

export default function Item(props) {

    // const classes = useStyles();

    const [counter, setCounter] = useState(0);
    const [itemTotalPrice, setItemTotalPrice] = useState(0);

    const handleAddClick = () => {
        // var roundedAmount = Number.parseFloat(props.itemData.prices[1].amount).toFixed(2);
        props.onPriceChange(props.itemData, props.itemData.counter + 1, "ADD");
        setItemTotalPrice(itemTotalPrice + props.itemData.prices[1].amount);
        setCounter(counter + 1);
    }

    const handleSubClick = () => {
        if (props.itemData.counter > 0) {
            props.onPriceChange(props.itemData, props.itemData.counter - 1, "SUB");
            setItemTotalPrice(itemTotalPrice - props.itemData.prices[1].amount);
            setCounter(counter - 1);
        }
    }

    const handleRemoveProductFromCartClick = () => {
        props.onRemoveProductFromCart(props.itemData);
    }

    return (
        <div className='item'>
            <img src='productMock.jpg' alt="" height="50" width="100" />
            <label>{props.itemData.title}</label>

            <IconButton aria-label="add" onClick={handleAddClick}>
                <AddIcon />
            </IconButton>
            <label>{props.itemData.counter}</label>
            <IconButton aria-label="remove" onClick={handleSubClick}>
                <RemoveIcon />
            </IconButton>

            <IconButton aria-label="delete" onClick={handleRemoveProductFromCartClick}>
                <DeleteIcon />
            </IconButton>

            <label>{props.itemData.itemTotalPrice}</label>

            {/* { console.log('Item rendered - counter', counter) } */}
        </div>
    );
}