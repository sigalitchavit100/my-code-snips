const productsMock = [
    {
       "id":22565423428,
       "title":"Product 1",
       "prices":[
          {
             "amount":150,
             "currency":"USD"
          },
          {
             "amount":19.0,
             "currency":"EUR"
          }
       ]
    },
    {
       "id":22565423394,
       "title":"Product 2",
       "prices":[
          {
             "amount":240.0,
             "currency":"USD"
          },
          {
             "amount":30,
             "currency":"EUR"
          }
       ]
    },
    {
       "id":22565423421,
       "title":"Product 3",
       "prices":[
          {
             "amount":333,
             "currency":"USD"
          },
          {
             "amount":65,
             "currency":"EUR"
          }
       ]
    },
    {
       "id":22565423368,
       "title":"Product 4",
       "prices":[
          {
             "amount":100,
             "currency":"USD"
          },
          {
             "amount":129,
             "currency":"EUR"
          }
       ]
    },
    {
       "id":22565423204,
       "title":"Product 5",
       "prices":[
          {
             "amount":120,
             "currency":"USD"
          },
          {
             "amount":150,
             "currency":"EUR"
          }
       ]
    }
 ];

 export default productsMock;